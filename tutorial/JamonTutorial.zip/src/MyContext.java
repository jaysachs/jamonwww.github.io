public class MyContext {
  private boolean secure;

  public boolean isSecure() {
    return secure;
  }
  
  public void setSecure(boolean secure) {
    this.secure = secure; 
  }
}
